# @localevolve/local-biz-factory-engine

> v0.1.0 preview. Part of [LocalEvolve Factory](https://github.com/LocalEvolve/localevolve-factory).

Astro-based static site generator for SEO/GEO/AI-optimized local-business websites.

## Install

```bash
npm install @localevolve/local-biz-factory-engine
```

## CLI

```bash
factory init <archetype>      # Scaffold a new project
factory wire                  # Generate site assets from data
factory build                 # astro build (auto-runs wire if needed)
factory validate              # Run validator registry (advisory in v1)
factory doctor                # Pre-flight companion-plugin check
factory --version             # Print engine version
```

`lbf` is installed as an alias.

## Programmatic API

```ts
import { build, schemas } from '@localevolve/local-biz-factory-engine';

const result = await build({ projectDir: process.cwd() });
console.log(result.success, result.generatedFiles);

const business = schemas.shared.business.parse(myData);
```

## Archetypes (v1)

- `mobile-service`
- `restaurant`
- `auto-dealer`

## Wire-input contract restriction (v1)

`src/content.config.ts`, `astro.config.mjs`, and `.ts` files under `src/data/**` or `src/content/**` MUST NOT import project-relative paths outside the hashed set. Permitted: npm packages, other files in `src/data`/`src/content`, node stdlib. `factory doctor` lints for violations; `factory wire` errors on violation. See parent README for rationale.

## License

MIT.
