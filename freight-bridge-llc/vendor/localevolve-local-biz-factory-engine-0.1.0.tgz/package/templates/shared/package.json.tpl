{
  "name": "{{ name }}",
  "type": "module",
  "version": "0.0.1",
  "private": true,
  "engines": { "node": ">=22.12.0" },
  "scripts": {
    "dev": "factory wire && astro dev",
    "build": "factory build",
    "wire": "factory wire",
    "validate": "factory validate",
    "doctor": "factory doctor",
    "preview": "astro preview"
  },
  "dependencies": {
    "@localevolve/local-biz-factory-engine": "^{{ engineVersion }}",
    "@astrojs/sitemap": "^3.7.2",
    "astro": "^6.1.5",
    "zod": "^4.4.3"
  },
  "factory": {
    "archetype": "{{ archetype }}",
    "flags": {},
    "mcp": { "servers": [] }
  }
}
