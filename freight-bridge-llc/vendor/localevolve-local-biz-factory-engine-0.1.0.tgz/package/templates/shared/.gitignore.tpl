node_modules/
dist/
.astro/
.factory/
.DS_Store
*.log
